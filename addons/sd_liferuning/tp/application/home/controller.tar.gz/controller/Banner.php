<?php
namespace app\home\controller;

use app\home\model\BannerModel;
use app\home\model\IndexModel;
use app\home\model\CommonModel;
use think\Controller;
use think\Request;
use think\Session;

class Banner extends Controller
{
    public function _iniaialize(Request $request = null)
    {


    }
    /**
     * banner类
     * 列表
     */
    public function index(Request $request){
      global $_W;
      $UserSession = Session::get('we7_account');
        if(empty($UserSession))
            header('Location:'.$_W['setting']['copyright']['url']);
        else
            //var_dump($UserSession['key']);die;
            $data = [
                'appid' => $UserSession['key'],
                'secret' => $UserSession['secret'],
                'uniacid' =>$UserSession['uniacid']
            ];
        $results = IndexModel::instance()->checkLogin($data);
        $result = IndexModel::instance()->insertWei($data,$UserSession['uniacid']);
        Session::set('bus_bid',$result['bid']);
        //var_dump($result);die;
        //var_dump(1);die;
        //$bid = $request->get('bid');
        $bid = $this->_getBid();
        $field = 'banid,bid,pic,url,sort,createtime';
        $result = BannerModel::instance()->banlist($bid,$field);
        //var_dump($result);die;
        foreach ($result as &$val){
            //var_dump( uploadpath('banner',$val['pic']));die;
            $val['pic'] = uploadpath('banner',$val['pic']);

            $val['createtime'] = date('Y-m-d H:i:s',$val['createtime']);
        }
        return view('banner/index',['data'=>$result]);
    }
    /**
     *
     * 添加
     */
    public function add(){
        return view('banner/add');
    }

    /**
     * 添加数据库
     */
    public function insert(Request $request){
        $bid = $this->_getBid();
        $bid = $this->_getBid();
        $pic = CommonModel::instance()->upload('banner');
        $data = $request->post();
        $data['pic'] = $pic;
        $data['bid'] = $bid;
        $data['createtime'] = time();
        $result = BannerModel::instance()->baninster($data);
        if($result == 1){
            $this->success('添加成功', 'Banner/index');
        }else{
            $this->error('新增失败');
        }

    }
    
    /**
     * 删除
     */
    public function delete(Request $request){
        $banid = $request->get('id');
        $result = BannerModel::instance()->deleteban($banid);
        return $result;
    }
    

}
