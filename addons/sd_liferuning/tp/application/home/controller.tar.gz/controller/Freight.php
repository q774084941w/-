<?php
namespace app\home\controller;

use app\home\model\FreightModel;
use think\Controller;
use think\Request;

class Freight extends Controller
{
    public function _iniaialize(Request $request = null)
    {


    }
    /**
     * 运费模板展示
     * @return \think\response\View
     *
     */
    public function index()
    {
        $bid = $this->_getBid();
        $data = FreightModel::instance()->show($bid);
        foreach ($data as &$val){
            if($val['status'] == 1){
                $val['status'] = '正常';
            }elseif ($val['status'] == 0){
                $val['status'] = '关闭';
            };

            $val['createtime'] == 0 ? $val['createtime'] = '' :$val['createtime'] = date('Y-m-d H:i:s',$val['createtime']);
            $val['handletime'] == 0 ? $val['handletime'] = '' :$val['handletime'] = date('Y-m-d H:i:s',$val['handletime']);
        }
        return view('freight/index',['data'=>$data]);
    }
    /**
     * 编辑
     */
    public function edit(Request $request){
        $id = $request->get('id');
        $data = FreightModel::instance()->showdata($id);
        return view('freight/edit',['data'=>$data]);
    }

    /**
     * 运费模板添加
     * @return \think\response\View
     *
     */
    public function add()
    {
        return view('freight/add');
    }
    /**
     * 详情
     * @return \think\response\View
     *
     */
    public function show(Request $request)
    {
        $id = $request->get('id');
        $data = FreightModel::instance()->showdata($id);
        $data['unit'] == 0 ? $data['unit'] = '重量' : $data['unit'] = '件数';
        $data['createtime'] = date('Y-m-d H:is',$data['createtime']);
        return view('freight/show',['data'=>$data]);
    }
    /**
     * 添加数据库
     * @param Request $request
     */
    public function insert(Request $request){
        $bid = $this->_getBid();
        $data = $request->post();
        if($data['city']){
            $data['createtime'] = time();
            $data['bid'] = $bid;
            FreightModel::instance()->insert($data);
            $this->success('添加成功', 'freight/index');
        }else{
            $this->error('未选择配送地址');
        }


    }
    /**
     * 开启关闭
     */
    public function soldOut(Request $request){
        $type = $request->post();
        $result = FreightModel::instance()->soldOut($type);
        return $result;
    }
    /**
     * 修改数据库
     */
    public function editinsert(Request $request){
        $data = $request->post();
        $data['handletime'] = time();
        $result = FreightModel::instance()->editinsert($data);
        if($result == 1){
            $this->success('添加成功', 'freight/index');
        }else{
            $this->error('修改失败');
        }
    }
    
}
