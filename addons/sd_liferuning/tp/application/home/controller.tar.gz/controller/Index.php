<?php
namespace app\home\controller;

use app\home\model\IndexModel;
use think\Controller;
use think\Request;
use think\Session;
use think\Db;


class Index extends Controller
{
    /**
     * 登录
     */
    public function _iniaialize(Request $request = null)
    {


    }
    public function test(){
        $file=file_get_contents(ROOT_PATH.'/wxlog.txt');
        print_r(json_decode($file));
    }
    public function login(){
        global $_W;
      echo   header('Location:'.'https://'.$_SERVER['HTTP_HOST']);
    }
    /**
     * 获取token
     */
    public function stati(){
        if (session('access_token') && session('expire_time') > time()) {

            return session('access_token');
        } else {
            $result = $this->_getBid();
            $ress = Db::name('business')->where('bid', $result)->find();
            $appid = $ress['appid'];
            $appsecret = $ress['secret'];
            $session_url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" . $appid . "&secret=" . $appsecret;
            $res = file_get_contents ( $session_url );
            $ress = json_decode($res);
            $access_token = $ress->access_token;
            if(empty($ress)){
                $res = file_get_contents ( $session_url );
                $ress = json_decode($res);
                $access_token = $ress->access_token;
                return $access_token;
            }
            //将重新获取到的access_token存到session里
            session('access_token',$access_token);
            echo 1;
            session('expire_time',time() + 3600);
            return $access_token;
        }
    }
    public function WeChatprogram($url,$data){
        $datas = json_encode($data);
        $options = array(
            'http' => array(
                'method' => 'post',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' =>$datas,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        //return $result;
        $res = json_decode($result);
        return $res;
    }
    /**
     * 登录检测
     */
    public function checkLogin(Request $request){
    }
    /**
     * 退出登录
     */
    public function quitLogin(){
        Session::delete('bus_bid');
        Session::delete('name');
        $this->success('退出成功', 'index/login');
    }
    /**
     * 概况分析
     * @param
     */
    public function index(){
        global $_W;
        $UserSession = Session::get('we7_account');
        if(empty($UserSession))
            header('Location:'.$_W['setting']['copyright']['url']);
        else
            $data = [
                'appid' => $UserSession['key'],
                'secret' => $UserSession['secret'],
                'uniacid' =>$UserSession['uniacid']
            ];
        $results = IndexModel::instance()->checkLogin($data);
        $result = IndexModel::instance()->insertWei($data,$UserSession['uniacid']);
        Session::set('bus_bid',$result['bid']);
        //var_dump($result);die;
        $result = $this->_getBid();
        if(!$result){
            $this->success('未登录', 'index/login');
        }
        $token = $this->stati();
        $url = 'https://api.weixin.qq.com/datacube/getweanalysisappiddailysummarytrend?access_token='.$token;
        $data =  [  'begin_date' =>date("Y-m-d",strtotime("-1 day")),'end_date' =>date("Y-m-d",strtotime("-1 day"))];
        $datas = json_encode($data);
        $options = array(
            'http' => array(
                'method' => 'post',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' =>$datas,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $results = file_get_contents($url, false, $context);
        //return $result;
        $res = json_decode($results);
        if(empty($res->list)){
            return view('index/index',['stitc' => $res->list]);
        }
        return view('index/index',['stitc' => $res->list[0]]);
    }

    /**
     * 用户分析
     * @param
     */
    public function user(){
        $result = $this->_getBid();
        if(!$result){
            $this->success('未登录', 'index/login');
        }
        //昨日
        $token = $this->stati();
        $url = 'https://api.weixin.qq.com/datacube/getweanalysisappiddailyvisittrend?access_token='.$token;
        $data = [  'begin_date' =>date("Y-m-d",strtotime("-1 day")),'end_date' =>date("Y-m-d",strtotime("-1 day"))];
        $res = $this->WeChatprogram($url,$data);
        if(empty($res->list)){
            return view('index/user',['stitc' => $res->list]);
        }
        if($ress = db('yestoday')->where('times', $res->list[0]->ref_date)->find()){
            $this->assign('stitc',$res->list[0]);
            $this->fetch('index/user');

        }else{
            db('yestoday')->insert([
                'times'=>$res->list[0]->ref_date,          //时间
                'yestody'=>$res->list[0]->visit_uv_new,  //新用户
                'opens'=>$res->list[0]->session_cnt,     //打开次数
                'visit_uv'=>$res->list[0]->visit_uv,       //访问人数
                'stay_time_uv'=>$res->list[0]->stay_time_uv,         //停留时间
                'visit_pv'=>$res->list[0]->visit_pv,   //访问次数
            ]);
        }
        $this->assign('stitc',$res->list[0]);
        return view('index/user');
    }

    /**
     * 访问分析
     * @param
     */
    public function visit(){
        return view('home/statistics/visit');
    }

    public function stics(){
        $data =  db('stitc')->limit(5)->field('times,open')->order('id desc')->select();
        echo json_encode(['res'=>$data]);
    }
    public function userStics(){
        $data =  db('yestoday')->limit(5)->field('times,visit_uv')->order('id desc')->select();
        echo json_encode(['res'=>$data]);
    }



}
