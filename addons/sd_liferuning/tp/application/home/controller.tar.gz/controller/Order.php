<?php
namespace app\home\controller;

use app\home\model\OrderModel;
use app\home\model\ExpressModel;
use think\Controller;
use think\Request;

class Order extends Controller
{
    public function _iniaialize(Request $request = null)
    {


    }
    /**
     * 订单类
     * @return \think\response\View
     *
     * 代付款
     */
    public function index()
    {
        $bid = $this->_getBid();
        $status = 0;
        $result = OrderModel::instance()->orderlist($bid,$status,'time desc');
        foreach($result as $k=>$v){
            $data = [];
            $data = $v;
            $data['status'] = '待付款';
            $v['time'] == 0 ? $data['time'] = '' :$data['time'] = date('Y-m-d H:i:s',$v['time']);
            $result->offsetSet($k,$data);
        }

        return view('order/index',['data'=>$result]);
    }
    /**
     * 待接单
     */
    public function delivergoods()
    {
        $bid = $this->_getBid();
        $status = 1;
        $result = OrderModel::instance()->orderlist($bid,$status,'id asc');
        
        $express = ExpressModel::instance()->exprlist($bid);

        foreach($result as $k=>$v){
            $data = [];
            $data = $v;
            $data['status'] = '待接单';
            $v['time'] == 0 ? $data['time'] = '' :$data['time'] = date('Y-m-d H:i:s',$v['time']);
            $result->offsetSet($k,$data);
        }
        return view('order/delivergoods',['data'=>$result,'express'=>$express]);
    }
    /**
     * 配送中
     */
    public function takegoods()
    {
        $bid = $this->_getBid();
        $status = 2;
        $result = OrderModel::instance()->orderlist($bid,$status,'time asc');

        foreach($result as $k=>$v){
            $data = [];
            $data = $v;
            $data['status'] = '配送中';
            $v['time'] == 0 ? $data['time'] = '' :$data['time'] = date('Y-m-d H:i:s',$v['time']);
            $result->offsetSet($k,$data);
        }
        return view('order/takegoods',['data'=>$result]);
    }
    /**
     * 已完成
     */
    public function complete()
    {
        $bid = $this->_getBid();
        $status = 3;
        $result = OrderModel::instance()->orderlist($bid,$status,'id asc');

        foreach($result as $k=>$v){
            $data = [];
            $data = $v;
            $data['status'] = '已完成';
            $v['time'] == 0 ? $data['time'] = '' :$data['time'] = date('Y-m-d H:i:s',$v['time']);
            $result->offsetSet($k,$data);
        }
        return view('order/complete',['data'=>$result]);
    }
    /**
     * 已关闭
     */
    public function occlude()
    {
        $bid = $this->_getBid();
        $status = -1;
        $result = OrderModel::instance()->orderlist($bid,$status,'createtime desc');

        foreach($result as $k=>$v){
            $data = [];
            $data = $v;
            $data['status'] = '已关闭';
            $v['createtime'] == 0 ? $data['createtime'] = '' :$data['createtime'] = date('Y-m-d H:i:s',$v['createtime']);
            $result->offsetSet($k,$data);
        }
        return view('order/occlude',['data'=>$result]);
    }
    /**
     * 详情
     */
    public function details(Request $request){
        $orderid = $request->get('orderid');
        $bid = $this->_getBid();
        $result = OrderModel::instance()->details($bid,$orderid);
        return view('order/occlude',['data'=>$result]);
    }
    /**
     * 详情
     */
    public function show(Request $request){
        $orderid = $request->get('id');
        $result = OrderModel::instance()->showlist($orderid);
	    $numz  = $totalpricez = 0;
//        foreach ($result['goods'] as &$val){
//            $numz +=  $val['num'];
//            $totalpricez += $val['total_price'];
//        }
        if($result['status'] == 0)$result['status'] = '待付款';
        if($result['status'] == 1)$result['status'] = '待接单';
        if($result['status'] == 2)$result['status'] = '配送中';
        if($result['status'] == 3)$result['status'] = '已完成';
        //var_dump($result['time'] );die;
        $result['time'] == 0 ? $result['time'] = '' : $result['time'] = date('Y-m-d h:i:s',$result['time']);
       // var_dump($result['time']);die;
//        $result['time'] == 0 ? $result['time'] = '' : $result['time'] = date('Y-m-d h:i:s',$result['time']);
//        $result['time'] == 0 ? $result['time'] = '' : $result['time'] = date('Y-m-d h:i:s',$result['time']);
//        $result['time'] == 0 ? $result['time'] = '' : $result['time'] = date('Y-m-d h:i:s',$result['time']);
        return view('order/show',['data'=>$result]);
    }
    /**
     * 添加快递
     */
    public function addexpress(Request $request){
        $data = $request->get();
        $result = OrderModel::instance()->addexpress($data);
       if($result > 0){
            $this->success('添加成功', 'order/index');
        }else{
            $this->error('新增失败');
        }
    
    }

 

    
}
