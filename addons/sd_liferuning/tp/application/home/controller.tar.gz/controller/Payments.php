<?php
namespace app\home\controller;

use app\home\model\PaymentsModel;
use app\home\model\CommonModel;
use think\Controller;
use think\Request;

class Payments extends Controller{
    public function _iniaialize(Request $request = null)
    {


    }
    public function index(){
        $bid = $this->_getBid();
        $field = 'bid,appid,secret,key,mchid';
        $result = PaymentsModel::instance()->paylist($bid,$field);
        // var_dump($result);exit;
        return view('payments/index',['data'=>$result,'bid'=>$result[0]['bid']]);
    }


    public function edit(){
        $id = $this->_getBid();
        $result = PaymentsModel::instance()->payonelist($id);
//        var_dump($result);exit;
        return view('payments/edit',['data'=>$result]);
    }
//
//
//
    public function editer(Request $request){

        $data = $request->post();

        $bid =  $data['bid'];
//      $field = 'name,address,phone';
        $result = PaymentsModel::instance()->payeditlist($bid,$data);
        if($result){
            $str = '<?php
//配置文件
return [
    \'APPID\'           => \''.$data['appid'].'\',
    \'MCHID\'           => \''.$data['mchid'].'\',     //商户号（必须配置，开户邮件中可查看）
    \'KEY\'             => \''.$data['key'].'\',        //商户支付密钥，参考开户邮件设置（必须配置，登录商户平台自行设置）
    \'APPSECRET\'       => \''.$data['secret'].'\',        //公众帐号secert（仅JSAPI支付的时候需要配置， 登录公众平台，进入开发者中心可设置）
    \'SSLCERT_PATH\'    => \'/cert/apiclient_cert.pem\',   //设置商户证书路径
    \'SSLKEY_PATH\'     => \'/cert/apiclient_key.pem\',   //设置商户证书路径
    \'WEIXIN_URL\'      => \'https://xq.135k.com/api/Paynotify/wxgoodsnotify\',
    \'REPORT_LEVENL\'   => 1,    //接口调用上报等级，默认紧错误上报(0.关闭上报; 1.仅错
];';
            $fileName = dirname(dirname(dirname(__FILE__))).'/extra/wxpay.php';
            $result = file_put_contents($fileName,$str);
            $this->success('修改成功', 'payments/index');
        }else{
            $this->error('修改失败');
        }
    }
}
