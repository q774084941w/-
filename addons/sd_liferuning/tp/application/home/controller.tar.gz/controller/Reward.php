<?php
namespace app\home\controller;

use app\home\model\RewardModel;
use think\Controller;
use think\Request;

class Reward extends Controller
{
    public function _iniaialize(Request $request = null)
    {


    }
    /*
     * 主页
     * */
    public function index(){
        return $this->fetch('reward/index');
    }
    /**
     * 0 开启  1 关闭
     */
    public function soldOut(Request $request){
        $id = $request->post('goodsid');
        $status = $request->post('status');
        $result  = RewardModel::instance()->soldOut($status,$id);
        return $result;
    }
    /**
     * 编辑
     */
    public function edit(Request $request){
        $id = $request->get('id');
        $bid = $this->_getBid();
        $result = CouponModel::instance()->couponedit($id);
        list($goods,$meuns) = CouponModel::instance()->addlist($bid);

        return view('coupon/edit',['data'=>$result,'goods'=>$goods,'menus'=>$meuns]);
    }

}
