<?php
namespace app\home\controller;


use think\Controller;
use think\Request;
use think\Db;

class Set extends Controller{
    public function _iniaialize(Request $request = null)
    {


    }
    public function index()
    {
        return view('set/index');
    }

}
