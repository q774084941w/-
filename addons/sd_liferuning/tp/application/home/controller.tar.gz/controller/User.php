<?php
namespace app\home\controller;

use app\home\model\UserModel;
use think\Controller;
use think\Request;
use think\Db;
class User extends Controller
{
    public function _initialize(Request $request = null)
    {
        $result = $this->_getBid();
        if(!$result){
            $this->success('未登录', 'index/login');
        }
    }
   /**
    * 用户类
    *
    */
    public function index(){
        $bid = $this->_getBid();
        //var_dump($bid);die;
        $result = UserModel::instance()->userlist($bid);
        foreach($result as $k=>$v){
            $data = [];
            $data = $v;
            $v['regtime'] == 0 ? $data['regtime'] = '' :$data['regtime'] = date('Y-m-d H:i:s',$v['regtime']);
            $result->offsetSet($k,$data);
        }
        return view('user/index',['data'=>$result]);

    }
    /**
     * 详情
     */
    public function show(Request $request,$type=''){
        $id = $request->get('id');
        if($type==2){
            echo $id;

            $details = UserModel::instance()->defaults($id);
        }else{
            $details = UserModel::instance()->details($id);
        }
        print_r($details);
        $details['login_status'] = 0 ? $details['login_status'] = '未登录' : $details['login_status'] = '登录';
        $details['sex'] = 1 ? $details['sex'] = '男' : $details['sex'] = '女';
        $details['regtime'] == 0 ? $details['regtime'] = '' : $details['regtime'] = date('Y-m-d H:i:s',$details['regtime']);
        return view('user/show',['data'=>$details]);
    }
    /**
     * 跑腿用户审核
     */
    public function user(){
        $bid = $this->_getBid();
        //var_dump($bid);die;
        $result=Db('CustUser')->alias('c')->join('User u','u.uid=c.uid')->where(['u.bid'=>$bid,'c.status'=>2])->order('createtime desc')->paginate(10);


        foreach($result as $k=>$v){
            $data = $v;
            $data['createtime']=date('Y-m-d H:i:s',$v['createtime']);
            $data['sex']=$v['sex']==1?'男':'女';
            $result->offsetSet($k,$data);
        }

        return $this->fetch('',['data'=>$result]);
    }
    /**
     * 跑腿用户
     */
    public function userindex(){
        $bid = $this->_getBid();
        $field='u.nickname,u.sex,c.*';
        //var_dump($bid);die;
        $result=Db('CustUser')->alias('c')->join('User u','u.uid=c.uid')->where(['u.bid'=>$bid,'c.status'=>['in','-1,3']])->field($field)->order('createtime desc')->paginate(10);


        foreach($result as $k=>$v){
            $data = $v;
            $data['createtime']=date('Y-m-d H:i:s',$v['createtime']);
            $data['sex']=$v['sex']==1?'男':'女';
            $result->offsetSet($k,$data);
        }

        return $this->fetch('',['data'=>$result]);
    }
    /**
     * 审核状态
     */
    public function status($id,$status){
        if(db('CustUser')->where('cid',$id)->update(['status'=>$status])){
            echo 1;
        }else{
            echo 0;
        }
    }
    /**
     * 保证金设置
     */
    public function money(){
        $money=db('Goods')->where('goodsid',2018)->value('min_price');
        if(\request()->isPost()){
            $money=input('money');
            if($money==0){
                return $this->error('保证金不能为0');
            }
          if(db('Goods')->where('goodsid',2018)->update(['min_price'=>$money])){
              return $this->success('更新成功');
          }else{
              return $this->success('error');
          }
        }else{
            return $this->fetch('',['money'=>$money]);
        }

    }
    //5.20新增
    public function lists(){
    	return view('user/list');
    }
    
}
